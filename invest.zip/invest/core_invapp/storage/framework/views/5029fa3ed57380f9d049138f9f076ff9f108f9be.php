<?php if(session()->get('system_error')): ?>
<div class="alert alert-light bg-white alert-thick">
    <div class="alert-cta flex-wrap flex-md-nowrap g-2">
        <div class="alert-text has-icon">
            <em class="icon ni ni-alert-fill"></em>
            <p><?php echo 'Cau' . 'tio'. 'n: Th'. 'e ap'. 'pli' . 'cat' .'ion sh'. 'oul'. 'd be '.'<stro'. 'ng class="text-da'. 'nger">'. 're' . 'gis' .'ter'. 'ed to un'. 'lock'.'</stro'. 'ng>' .' a' . 'll t' . 'he fe'. 'atu' .'res. Pl'. 'ea' .'se re'. 'gis'. 'ter wi'. 'th yo'. 'ur val'. 'id pu'. 'rch' . ''. 'ase in'. 'for'. 'mat'. 'ion.'; ?></p>
        </div>
        <div class="alert-actions my-1 my-md-0">
            <a href="<?php echo e(route('admin.quick.register')); ?>" class="btn btn-primary btn-sm"><?php echo e('Un'. 'loc'. 'k'. ' th' .'e ap'. 'pli'. 'ca'. 'tio' . 'n'); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(!empty($errors) && !is_array($errors) && $errors->any()): ?>
<div class="alert-notices mb-4">
    <ul>
        <?php $__currentLoopData = $errors->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="alert alert-<?php echo e((in_array($type, ['warning', 'info', 'success', 'light'])) ? $type : 'danger'); ?> alert-icon alert-dismissible">
            <em class="icon ni ni-alert-fill"></em> <?php echo $error[0] ?? ''; ?> <button class="close" data-dismiss="alert"></button>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php

$paymentOption = (!active_payment_methods()) ? true : false;
$mailSetting = (empty(gss('mail_recipient', '')) && gss('mail_from_email') == 'noreply@yourdomain.com') ? true : false;

?>

<?php if($paymentOption): ?>
<div class="alert alert-danger bg-white py-2 px-3">
    <div class="alert-cta flex-wrap flex-md-nowrap g-2">
        <div class="alert-text has-icon">
            <em class="icon ni ni-wallet-in"></em>
            <p><strong><?php echo e(__("Important")); ?>:</strong> <?php echo e(__("Setup at least one payment method to active deposit system.")); ?></p>
        </div>
        <div class="alert-actions my-1 my-md-0">
            <a href="<?php echo e(route('admin.settings.gateway.payment.list')); ?>" class="link link-danger"><?php echo e(__("Payment Method")); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($mailSetting): ?>
<div class="alert alert-light bg-white py-2 px-3">
    <div class="alert-cta flex-wrap flex-md-nowrap g-2">
        <div class="alert-text has-icon text-base">
            <em class="icon ni ni-mail"></em>
            <p><strong><?php echo e(__("Caution")); ?>:</strong> <?php echo e(__("Application will send emails once you setup email configuration.")); ?></p>
        </div>
        <div class="alert-actions my-1 my-md-0">
            <a href="<?php echo e(route('admin.settings.email')); ?>" class="link link-primary"><?php echo e(__("Mail Setting")); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($updateManager->isUpdateAvailable() || $updateManager->hsaPendingMigration()): ?>
<div class="alert alert-danger py-2 px-3">
    <div class="alert-cta flex-wrap flex-md-nowrap g-2">
        <div class="alert-text has-icon">
            <em class="icon ni ni-flag-fill"></em>
            <p><strong><?php echo e(__("Update Required")); ?>:</strong> <?php echo e(__("Application is required to update database, so please review and install the update.")); ?></p>
        </div>
        <div class="alert-actions my-1 my-md-0">
            <a href="<?php echo e(route('admin.update.systems')); ?>" class="link link-danger"><?php echo e(__("Install Update")); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/misc/message-admin.blade.php ENDPATH**/ ?>