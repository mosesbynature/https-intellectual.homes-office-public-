<div class="nk-footer nk-auth-footer-full">
    <div class="container wide-lg">
        <?php if(Panel::navigation('footer')): ?>
        <div class="row g-3">
            <div class="col-lg-6 order-lg-last">
                <?php echo Panel::navigation('footer', ['class' => 'justify-content-center justify-content-lg-end']); ?>

            </div>
            <div class="col-lg-6">
                <div class="nk-block-content text-center text-lg-left">
                    <p class="text-soft"><?php echo __(site_info('copyright')); ?></p>
                </div>
            </div>
        </div>
        <?php else: ?> 
        <p class="text-soft text-center"><?php echo __(site_info('copyright')); ?></p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/auth/layouts/footer.blade.php ENDPATH**/ ?>