<?php 

$color = (isset($attr['color']) && $attr['color']) ? $attr['color'] : false;
$social_class = (isset($attr['class']) && $attr['class']) ? ' '.$attr['class'] : '';
$social_parent = (isset($attr['parent']) && $attr['parent']) ? true : false;

$size = (isset($attr['size']) && $attr['size']) ? ' '.$attr['size'] : '';
$gaps = (isset($attr['gaps']) && $attr['gaps']) ? ' '.$attr['gaps'] : '';

$color_class = ($color=='auto') ? ' text-soft' : ((!empty($color)) ? ' text-'.$color : '');

?>

<?php if(!empty($socials) && count($socials) > 0): ?>
<?php if($social_parent): ?>
<ul class="nk-socials<?php echo e($social_class.$gaps); ?>">
<?php endif; ?>

	<?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li class="social-item">
		<a class="social-link<?php echo e($color_class.$size); ?>" href="<?php echo e($item['link']); ?>" title="<?php echo e($item['title']); ?>" target="_blank"><em class="icon ni ni-<?php echo e($item['icon']); ?>"></em></a>
	</li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($social_parent): ?>
</ul>
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/misc/panel/socials.blade.php ENDPATH**/ ?>