<p class="alert alert-danger fs-13"><?php echo '<strong>Important:</strong> As per <a href="'. the_link('codecanyon.net/licenses/standard'). '" target="_blank">'. ucfirst('env') .'ato License</a> terms, one '.'purchase code'.' is valid to use one application. '.'Please activate'.' the application into correct domain '. '/' .' path to '.'avoid any kind'.' of issues'.'.'; ?></p>
<p><?php echo '<strong>Caution:</strong> '.'The following data will be send to ' . '<strong>Sof' . 'tnio</strong>' . ' server to validate your '. 'purchase information' .''.'.'; ?></p>
<div class="card card-bordered mb-4">
    <table class="table fs-12px bg-lighter">
        <tr>
            <td width="120"><?php echo 'Registration Info:'; ?></td>
            <td><?php echo 'Purchase' . ' Code' . ', <br>' . 'Username & Email'; ?></td>
        </tr>
        <tr>
            <td><?php echo 'Site' . '/' . 'App Name:'; ?></td>
            <td><span class="text-wrap wide-120px"><?php echo e(base64_encode(site_info('name'))); ?></span></td>
        </tr>
        <tr>
            <td><?php echo 'Site' . '/' . 'App URL:'; ?> </td>
            <td>
                <span class="text-wrap wide-120px"><?php echo e(str_replace(['https://', 'http://'], '', site_info('url'))); ?></span>
            </td>
        </tr>
        <tr>
            <td><?php echo 'Installed' . ' ' . 'Version:'; ?></td>
            <td><?php echo e('v'.config('app'.'.'.'version')); ?></td>
        </tr>
    </table>
</div>
<p class="alert alert-warning fs-13px font-italic"><?php echo '<strong>Please Note:</strong> <br>'.'We will never collect any ' . 'confidential' . ' data such as '. 'transactions' .', emails or usernames.'; ?></p><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\vendor\softnio\utility-services\src/Views/system/info.blade.php ENDPATH**/ ?>