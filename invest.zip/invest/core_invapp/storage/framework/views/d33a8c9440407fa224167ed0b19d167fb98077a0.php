<?php 

$nav_class = (isset($attr['class']) && !empty($attr['class'])) ? ' '.$attr['class'] : '';

$nav_title = (isset($attr['heading']) && $attr['heading']) ? true : false;
$nav_parent = (isset($attr['parent']) && $attr['parent']) ? true : false;
$nav_alone = (isset($attr['alone']) && $attr['alone']) ? true : false;

?>

<?php if(filled($items)): ?>
	<?php if($nav_parent): ?>
	<div class="nk-footer-links">
	<?php endif; ?>
	
	<?php if($nav_alone): ?>
	<ul class="nav nav-sm<?php echo e($nav_class); ?>">
	<?php endif; ?>

		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if( (Auth::check() && $menu->access =='login') || ($menu->access =='public') ): ?>
		<li class="nav-item<?php echo e((request()->url()==$menu->link) ? ' active' : ''); ?>">
			<a class="nav-link" href="<?php echo e($menu->link); ?>"<?php echo ($menu->menu_link) ? ' target="_blank"' : ''; ?>><?php echo e(__($menu->text)); ?></a>
		</li>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php echo Panel::lang_switcher(); ?>


	<?php if($nav_alone): ?>
	</ul>
	<?php endif; ?>
	
	<?php if($nav_parent): ?>
	</div>
	<?php endif; ?>

<?php endif; ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/misc/panel/nav-footer.blade.php ENDPATH**/ ?>