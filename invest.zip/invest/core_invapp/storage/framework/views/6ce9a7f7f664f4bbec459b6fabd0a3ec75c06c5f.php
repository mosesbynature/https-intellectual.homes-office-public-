<table style="width:100%;max-width:620px;margin:0 auto;">
    <tbody>
    <tr>
        <td style="text-align: center; padding:25px 20px 0;">
            <p style="font-size: 13px;"><?php echo __(get_email_copyright()); ?></p>
            <?php if(!empty(social_links('all')) && count(social_links('all')) > 0): ?> 
            <ul style="margin: 10px -4px 0;padding: 0;">
                <?php $__currentLoopData = social_links('all'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($item['link']) && $item['link']): ?>
                    <li style="display: inline-block; list-style: none; padding: 4px;">
                        <a style="display: inline-block;" href="<?php echo e($item['link']); ?>">
                            <?php echo e(ucfirst($social)); ?>

                            
                        </a>
                    </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </td>
    </tr>
    </tbody>
</table>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/emails/layouts/footer.blade.php ENDPATH**/ ?>