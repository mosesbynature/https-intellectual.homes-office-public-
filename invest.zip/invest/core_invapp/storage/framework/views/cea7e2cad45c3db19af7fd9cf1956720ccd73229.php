<?php if($errors->any()): ?>
<div class="alert-notices mb-4">
    <ul>
        <?php $__currentLoopData = $errors->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="alert alert-<?php echo e((in_array($type, ['warning', 'info', 'success', 'light'])) ? $type : 'danger'); ?> alert-icon">
            <em class="icon ni ni-alert-fill"></em> <?php echo $error[0] ?? ''; ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if(session()->has('unknown_error')): ?>
<div class="alert alert-warning">
    <ul>
        <li class="alert-icon centered"><em class="icon ni ni-alert-fill"></em><?php echo e(session()->pull('unknown_error')); ?></li>
    </ul>
</div>

<?php endif; ?>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/auth/partials/error.blade.php ENDPATH**/ ?>