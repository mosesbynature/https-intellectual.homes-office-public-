<?php

$witcher_class = (isset($attr['class']) && !empty($attr['class'])) ? ' '.$attr['class'] : '';

$switcher = sys_settings('language_switcher');
$showAs = sys_settings('language_show_as', 'default');
$ddSize = ($showAs == 'short') ? 'xs' : 'sm';
$trigger = ($showAs == 'code') ? strtoupper($selected['code']) : ucfirst($selected['label']);

?>

<?php if($switcher=='on' && !empty($langs)): ?>

<?php if($type == 'auth'): ?>
<div class="lang-switcher <?php echo e($witcher_class); ?>">
	<ul class="nav nav-sm">
<?php endif; ?>

	<li class="<?php echo e(($type == 'sidebar') ? 'nk-menu' : 'nav'); ?>-item<?php echo e(($type != 'auth') ? $witcher_class : ''); ?>">
		<div class="dropup">
			<a href="javascript:void(0)" class="dropdown-toggle dropdown-indicator has-indicator<?php echo e(($type == 'sidebar') ? ' nk-menu-link' : ' nav-link'); ?> lang-switch-btn toggle-tigger" data-toggle="dropdown">
				<?php if($type == 'sidebar'): ?>
				<span class="nk-menu-icon"><em class="icon ni ni-globe"></em></span>
				<span class="nk-menu-text"><?php echo e($trigger); ?></span>
				<?php else: ?> 
				<?php echo e($trigger); ?>

				<?php endif; ?>
			</a>
			<div class="dropdown-menu dropdown-menu-<?php echo e(($showAs == 'code') ? 'xxs' : $ddSize); ?> dropdown-menu-right">
				<ul class="language-list">
					<?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<a href="<?php echo e(route('language', ['lang' => $code])); ?>" class="language-item justify-center">
								<span class="language-name<?php echo e(($code == $selected['code']) ? ' fw-medium' : ''); ?>"><?php echo e(($showAs == 'code') ? strtoupper($code) : ucfirst($name)); ?></span>
							</a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	</li>

<?php if($type == 'auth'): ?>
	</ul>
</div>
<?php endif; ?>

<?php endif; ?>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/misc/panel/lang-switcher.blade.php ENDPATH**/ ?>