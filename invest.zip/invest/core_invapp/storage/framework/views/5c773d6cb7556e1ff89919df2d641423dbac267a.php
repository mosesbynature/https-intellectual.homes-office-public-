<?php 

$menu_class = (isset($attr['class']) && !empty($attr['class'])) ? ' '.$attr['class'] : '';

$menu_title = (isset($attr['heading']) && $attr['heading']) ? true : false;
$menu_parent = (isset($attr['parent']) && $attr['parent']) ? true : false;
$menu_alone = (isset($attr['alone']) && $attr['alone']) ? true : false;

?>

<?php if(filled($items)): ?>

	<?php if($menu_parent): ?>
	<div class="mainmenu-nav<?php echo e($menu_class); ?>">
	<?php endif; ?>

	<?php if($menu_alone): ?>
	<ul class="menu-list<?php echo e($menu_class); ?>">
	<?php endif; ?>

		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if( (Auth::check() && $menu->access =='login') || ($menu->access =='public') ): ?>
		<li class="menu-item<?php echo e((request()->url()==$menu->link) ? ' active' : ''); ?>">
		    <a href="<?php echo e($menu->link); ?>" class="menu-link nav-link"<?php echo ($menu->menu_link) ? ' target="_blank"' : ''; ?>>
		        <span class="menu-text"><?php echo e(__($menu->text)); ?></span>
		    </a>
		</li>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	<?php if($menu_alone): ?>
	</ul>
	<?php endif; ?>
	
	<?php if($menu_parent): ?>
	</div>
	<?php endif; ?>

<?php endif; ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/misc/panel/nav-mainnav.blade.php ENDPATH**/ ?>