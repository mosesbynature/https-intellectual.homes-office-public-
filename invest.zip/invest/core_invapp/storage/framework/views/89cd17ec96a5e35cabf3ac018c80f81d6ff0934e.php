<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">
                <?php echo site_info('copyright'); ?>

            </div>
            <div class="nk-footer-links">
                <ul class="nav nav-sm">
                    <?php echo Panel::lang_switcher(); ?>

                    <?php if(has_sysinfo()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.systeminfo')); ?>"><?php echo e(__("System Info")); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>