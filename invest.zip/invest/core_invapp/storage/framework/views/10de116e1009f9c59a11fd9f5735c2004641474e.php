

<?php $__env->startSection('title', __('Registration Complete')); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-bordered">
    <div class="card-inner card-inner-lg">
        <div class="nk-block-head text-center">
            <h4 class="nk-block-title"><?php echo e(__('Registration completed successfully.')); ?></h4>
        </div>
        <div class="nk-block-content text-center">
            <p><strong><?php echo e(__('Thank you for signing up!')); ?></strong></p>
            <p><?php echo e(__('We just need you to verify your email address. Please check your inbox including spam folder for a verification mail.')); ?></p>
            <div class="gap gap-md"></div>
            <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('auth.login.form')); ?>"><?php echo e(__('Return to Login')); ?></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/auth/confirm.blade.php ENDPATH**/ ?>