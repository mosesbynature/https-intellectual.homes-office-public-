

<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('heading', __("Oops! Why you're here?")); ?>
<?php $__env->startSection('message', __("We're sorry for inconvenience. It looks like you're trying to access a page that either has been deleted or never existed.")); ?>

<?php echo $__env->make('errors::custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/errors/404.blade.php ENDPATH**/ ?>