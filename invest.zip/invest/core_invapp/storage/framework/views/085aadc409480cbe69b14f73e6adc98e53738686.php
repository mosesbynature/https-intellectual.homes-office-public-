<div class="nk-content-sidebar" data-content="pageSidebar" data-toggle-screen="lg" data-toggle-overlay="true">
    <div class="nk-content-sidebar-inner" data-simplebar>
        <h6><?php echo e(__('Application Settings')); ?></h6>
        <ul class="nk-nav-tree">
            <li class="link-item"><a href="<?php echo e(route('admin.settings.global.general')); ?>"> <span><?php echo e(__('Global Settings')); ?></span></a>
                <ul>
                    <li class="link-item<?php echo e(is_route('admin.settings.global.general') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.global.general')); ?>"><?php echo e(__('General Settings')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.global.currency') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.global.currency')); ?>"><?php echo e(__('Manage Currencies')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.global.rewards') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.global.rewards')); ?>"><?php echo e(__('Rewards Program')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.global.referral') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.global.referral')); ?>"><?php echo e(__('Referral Settings')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.global.api') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.global.api')); ?>"><?php echo e(__('Third-Party API')); ?></a></li>
                </ul>
            </li>
            <li class="link-item"><a href="<?php echo e(route('admin.settings.gateway.option')); ?>"><?php echo e(__('Payment Options')); ?></a>
                <ul>
                    <li class="link-item<?php echo e(is_route('admin.settings.gateway.option') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.gateway.option')); ?>"><?php echo e(__('Deposit & Withdraw')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.gateway.payment.*') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.gateway.payment.list')); ?>"><?php echo e(__('Payment Method')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.gateway.withdraw.*') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.gateway.withdraw.list')); ?>"><?php echo e(__('Withdraw Method')); ?></a></li>
                </ul>
            </li>
            <?php if(has_route('admin.settings.investment.apps')): ?>
            <li class="link-item<?php echo e(is_route('admin.settings.investment.apps') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.investment.apps')); ?>"> <span><?php echo e(__('Investment Apps')); ?></span></a>
            </li>
            <?php endif; ?>
            <li class="link-item"><a href="<?php echo e(route('admin.settings.website')); ?>"> <span><?php echo e(__('Website Settings')); ?></span></a>
                <ul>
                    <li class="link-item<?php echo e(is_route('admin.settings.website') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.website')); ?>"><?php echo e(__('Site Information')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.website.userpanel') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.website.userpanel')); ?>"><?php echo e(__('User Dashboard')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.website.appearance') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.website.appearance')); ?>"><?php echo e(__('Brands & Themeing')); ?></a></li>
                    <li class="link-item<?php echo e(is_route('admin.settings.website.misc') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.website.misc')); ?>"><?php echo e(__('Miscellaneous')); ?></a></li>
                </ul>
            </li>
            <li class="link-item<?php echo e(is_route('admin.settings.email') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.settings.email')); ?>"><?php echo e(__('Email Configuration')); ?></a></li>
            <li class="link-item<?php echo e(is_route('admin.systeminfo') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.systeminfo')); ?>"><?php echo e(__('System Status')); ?></a></li>

            <?php if(has_route('admin.quick-setup') && sys_settings('system_super_admin', 0) == auth()->user()->id): ?>
            <li class="link-item<?php echo e(is_route('admin.quick-setup') ? ' active' : ''); ?>"><a href="<?php echo e(route('admin.quick-setup')); ?>"><?php echo e(__('Quick Setup')); ?> <em class="icon ni ni-arrow-long-right ml-2"></em></a></li>
            <?php endif; ?>

            <?php if(has_route('admin.system.cache') && sys_settings('system_super_admin', 0) == auth()->user()->id): ?>
            <li class="link-item">
                <a href="<?php echo e(route('admin.system.cache')); ?>"><?php echo e(__('Clear Cache')); ?> <em class="icon ni ni-reload ml-2"></em></a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/admin/settings/content-sidebar.blade.php ENDPATH**/ ?>