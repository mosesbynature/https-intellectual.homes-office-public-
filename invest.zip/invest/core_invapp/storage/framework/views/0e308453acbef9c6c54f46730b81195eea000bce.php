
<?php $__env->startSection('title', __('Module Setting')); ?>

<?php $__env->startSection('has-content-sidebar', 'has-content-sidebar'); ?>

<?php $__env->startSection('content-sidebar'); ?>
<?php echo $__env->make('admin.settings.content-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/admin/layouts/modules.blade.php ENDPATH**/ ?>