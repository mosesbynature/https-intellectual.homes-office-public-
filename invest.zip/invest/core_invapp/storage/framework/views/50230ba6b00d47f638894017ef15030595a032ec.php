<?php if(!empty(get_mail_branding())): ?> 
    <table style="width:100%;max-width:620px;margin:0 auto;">
        <tbody>
        <tr>
            <td style="text-align: center; padding-bottom:15px">
                <img class="logo-img" style="max-height: 50px; width: auto;" src="<?php echo e(get_mail_branding()); ?>" alt="<?php echo e(site_info('name')); ?>">
            </td>
        </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\frank\Desktop\xammp\htdocs\invest1\core_invapp\resources\views/emails/layouts/header.blade.php ENDPATH**/ ?>