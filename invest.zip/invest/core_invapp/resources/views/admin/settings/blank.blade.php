@extends('admin.layouts.master')
@section('title', __('Blank Page'))

@section('has-content-sidebar', 'has-content-sidebar')

@section('content-sidebar')
    @include('admin.settings.content-sidebar')
@endsection

@section('content')

@endsection
