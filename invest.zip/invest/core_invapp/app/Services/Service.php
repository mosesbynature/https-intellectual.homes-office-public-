<?php


namespace App\Services;


class Service
{

}
