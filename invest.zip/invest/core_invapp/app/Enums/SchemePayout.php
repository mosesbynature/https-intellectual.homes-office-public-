<?php


namespace App\Enums;


interface SchemePayout
{
    const AFTER_MATURED = 'after_matured';
    const TERM_BASIS = 'term_basis';
}
