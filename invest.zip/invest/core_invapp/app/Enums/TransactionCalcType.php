<?php


namespace App\Enums;


interface TransactionCalcType
{
    const DEBIT = 'debit';
    const CREDIT = 'credit';
    const NONE = 'none';
}
